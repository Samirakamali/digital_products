# in develop envir following should be true but in production env should be false

DEBUG = True
IS_DEVEL = True
ALLOWED_HOSTS = ['*']